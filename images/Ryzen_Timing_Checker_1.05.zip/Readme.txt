RTC - Ryzen Timing Checker

A simple utility to check the major & minor DRAM timings on Raven and Zeppelin based AMD Ryzen APUs & CPUs.
The utility will read the timings from the first logical memory controller (UMC0) only, as despite it is technically possible to use
asynchronous timings for each of the controllers such configuration is not officially encouraged nor possible for the time being.

The DDR4 specification includes three different tRFC (Refresh Command) timings (tRFC/tRFC2/tRFC4). Only one of these timings are used at the time, depending on the refresh mode. Refresh Mode: 1x = tRFC, 2x = tRFC2, 4x tRFC4. During a normal operation only 1x refresh mode is used and therefore the other tRFC timings (2/4) are not used. Because of that, these timings are not displayed by the utility either.

The utility contains no real time monitoring, meaning increments or decrements to the BCLK (and hence to MEMCLK) won't be reflected to the decoded cycle times or displayed MEMCLK frequency. After the utility has started (i.e. the GUI is visible) it has no overhead nor interference, meaning it can be left running to the background during benchmarking without any performance penalty.

** NOTE **: The user must have admin rights to run this utility! (Right click > "Run as Admin" or select "Run as Admin" option from the file properties).

The Stilt - 2/6/2017

